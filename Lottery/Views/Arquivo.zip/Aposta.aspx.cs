﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
 Requisitos Funcionais
 A aplicação deve permitir ao usuário cadastrar uma quantidade indefinida de apostas.
 A aplicação deve permitir ao usuário cadastrar aposta do tipo surpresinha (aposta
aleatória) ou informar os 6 números desejados da aposta.
 A aplicação deve permitir simular um sorteio de 6 números aleatórios.
 A aplicação deve permitir consultar a quantidade de acertos de cada aposta realizada.
 Cada aposta deve ser composta por um número identificador (número sequencial
gerado pelo sistema), data e hora da aposta e os 6 números.
*/

/*Fazer método que controle a quantidade de cliques sobre os checkboxes.
-Se forem clicados até 6 vezes, desabilitar o restantes dos checkboxes.
-Se forem clicados menos de 6 vezes, deixar o restante dos checkboxes habilitados.
-Ao final, enviar todos os números clicados para uma lista para ser gerada o
número para essa aposta.*/

namespace Lottery
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            List<int> listaTeste = GerarRandom();

            List<int> numSorteio = GerarRandom();

            if (!IsPostBack)
            {
                //Seta as propriedades do checkboxlist
                CheckBoxList1.CellPadding = 5;
                CheckBoxList1.CellSpacing = 5;
                CheckBoxList1.RepeatColumns = 6;
                CheckBoxList1.RepeatDirection = RepeatDirection.Vertical;
                CheckBoxList1.RepeatLayout = RepeatLayout.Flow;
                CheckBoxList1.TextAlign = TextAlign.Right;

                //Gera os 60 checkbox
                for (int i = 1; i <= 60; i++)
                {
                    CheckBoxList1.Items.Add(new ListItem(i.ToString()));
                }
            }
        }


        public List<int> GerarRandom()
        {
            List<int> listaRand = new List<int>();
            for (int i = 0; i < 6; i++)
            {
                Random r = new Random();
                int FuncRandom = r.Next(1, 60);

                //Vai gerando numero randomico até achar um que não esta contido na listaRand
                while (listaRand.Contains(FuncRandom))
                {
                    FuncRandom = r.Next(1, 60);//10
                }

                listaRand.Add(FuncRandom);
            }
            return listaRand;
        }



        protected void btnEnviarAposta_Click(object sender, EventArgs e)
        {
            int contador = 0;
            List<int> numerosSelecionados = new List<int>();

            if (CheckBoxList1 != null)
            {
                for (int i = 0; i < CheckBoxList1.Items.Count; i++)
                {
                    if (CheckBoxList1.Items[i].Selected)
                    {
                        numerosSelecionados.Add(Convert.ToInt32(CheckBoxList1.Items[i].Text));
                        contador++;
                    }
                }
            }

            //Instanciando Lista de MegaSena
            List<MegaSena> listaMegasena = new List<MegaSena>();

            //Verifico se é valido, ou seja, se quantidade de numeros selecionados é igual a 6
            if (contador == 6)
            {
                //Caso a sessão não seja nula, ou seja, ja existe jogo adicionado
                //Relaciono a sessão que contem salvo uma lista de megasenas a variavel listaMegasena
                if (Session["JogoSalvo"] != null)
                {
                    listaMegasena = (List<MegaSena>)Session["JogoSalvo"];
                }

                //Instancio nova classe MegaSena
                MegaSena mega = new MegaSena();
                mega.NumAposta = Guid.NewGuid().ToString();//Gerar um valor de ID
                mega.NumSelecionados = numerosSelecionados;//Adicionar a lista de numero selecionados de checkbox
                mega.Data = DateTime.Now;//Adicionar data e hora

                //Adicionar classe MegaSena na lista do tipo MegaSena
                listaMegasena.Add(mega);

                //Adicionar lista atualizada na sessão.
                Session["JogoSalvo"] = listaMegasena;

                //gridApostas.DataSource = numerosSelecionados;
                //gridApostas.DataBind();
            }
            //Caso usuário tentou adicionar um jogo com menos ou mais numeros, causando Erro
            else
            {
                message.Text = "A quantidade de numeros selecionados devem ser igual a 6.";
            }
        }

    }
}